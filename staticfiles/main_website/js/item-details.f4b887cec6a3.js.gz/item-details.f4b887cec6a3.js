$(document).ready(function(){
  // $('.carousel').carousel()
  $("#startdate").datepicker();
  $("#enddate").datepicker();
});
